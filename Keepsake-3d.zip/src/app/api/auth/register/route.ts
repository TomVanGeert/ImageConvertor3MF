import { NextRequest, NextResponse } from "next/server";
import { hashPassword, generateToken } from "../../../lib/serverUtils";

interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
}

// Simple in-memory DB for demo (replace with real DB in production)
const users: User[] = [];

export async function POST(req: NextRequest) {
  try {
    const { name, email, password } = await req.json();

    if (!name || !email || !password) {
      return NextResponse.json({ message: "Missing fields" }, { status: 400 });
    }

    // Check if email already exists
    if (users.find(u => u.email === email)) {
      return NextResponse.json({ message: "Email already registered" }, { status: 400 });
    }

    const passwordHash = await hashPassword(password);
    const newUser: User = {
      id: crypto.randomUUID(),
      name,
      email,
      passwordHash,
    };
    users.push(newUser);

    // Create session token
    const token = generateToken();
    const response = NextResponse.json({ message: "Registration successful" });
    response.cookies.set("session", token, { httpOnly: true, path: "/" });

    // In production, store the token in DB linked to the user
    (newUser as any).sessionToken = token;

    return response;
  } catch (err) {
    console.error(err);
    return NextResponse.json({ message: "Registration failed" }, { status: 500 });
  }
}
