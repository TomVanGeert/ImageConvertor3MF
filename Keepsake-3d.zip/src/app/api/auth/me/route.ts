import { NextRequest, NextResponse } from "next/server";

interface User {
  id: string;
  name: string;
  email: string;
  sessionToken?: string;
}

const users: User[] = [];

export async function GET(req: NextRequest) {
  try {
    const token = req.cookies.get("session")?.value;
    if (!token) return NextResponse.json({ user: null });

    const user = users.find(u => u.sessionToken === token);
    if (!user) return NextResponse.json({ user: null });

    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email } });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ user: null });
  }
}
